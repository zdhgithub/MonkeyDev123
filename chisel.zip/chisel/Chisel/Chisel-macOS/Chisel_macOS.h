// Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved
//
// This source code is licensed under the MIT license found in the
// LICENSE file in the root directory of this source tree.

#import <Cocoa/Cocoa.h>

//! Project version number for Chisel_macOS.
FOUNDATION_EXPORT double Chisel_macOSVersionNumber;

//! Project version string for Chisel_macOS.
FOUNDATION_EXPORT const unsigned char Chisel_macOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Chisel_macOS/PublicHeader.h>


