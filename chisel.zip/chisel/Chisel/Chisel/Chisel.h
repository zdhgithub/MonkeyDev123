// Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved
//
// This source code is licensed under the MIT license found in the
// LICENSE file in the root directory of this source tree.

#import <UIKit/UIKit.h>

//! Project version number for Chisel.
FOUNDATION_EXPORT double ChiselVersionNumber;

//! Project version string for Chisel.
FOUNDATION_EXPORT const unsigned char ChiselVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Chisel/PublicHeader.h>
